var main_8py =
[
    [ "led_brightness", "main_8py.html#a4a507a6b55df0fb3ea826794582e0aa1", null ],
    [ "led_setup", "main_8py.html#a6ef5ac3570ce2c3589413b978e830e1d", null ],
    [ "start_time", "main_8py.html#ae57958345b17f9ca8597330ba07e1a1c", null ]
];